import os
import logging
import json
import io
import contextlib
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from openai import OpenAI
from typing import Dict, Any, List

# --- Configuration ---
# التوكن ومعرف الدردشة المقدمين من المستخدم
TOKEN = "8013034309:AAHXro9tx28o9ydZNm2eUfEKVagG216HXos"
ALLOWED_CHAT_ID = 7428813091
MODEL_NAME = "gpt-4.1-mini" # نموذج قوي يدعم استدعاء الدوال (Tool Calling)

# إعداد التسجيل
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# تهيئة عميل OpenAI (يستخدم متغير البيئة OPENAI_API_KEY تلقائيًا)
client = OpenAI()

# --- Tool Definitions (for LLM) ---
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Performs a web search for up-to-date information or facts. Use this tool when the user asks a question that requires current knowledge or external data.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query in Arabic or English."
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_code",
            "description": "Executes Python code to solve complex mathematical problems, perform data processing, or run logic. Use this tool for calculations or when a logical script is needed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "The Python code to execute. The code must be self-contained and print its output."
                    }
                },
                "required": ["code"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "generate_image",
            "description": "Generates an image based on a detailed text prompt using DALL-E. Use this tool when the user explicitly asks to create or generate an image.",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "The detailed prompt for the image generation, preferably in English for better results."
                    }
                },
                "required": ["prompt"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "creative_planner",
            "description": "Generates highly imaginative, creative, and out-of-this-world ideas, stories, or concepts. Use this for requests that involve fantasy, science fiction, abstract concepts, or anything 'outside the world'.",
            "parameters": {
                "type": "object",
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": "The topic or concept for which the creative plan is needed."
                    }
                },
                "required": ["topic"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "strategic_planner",
            "description": "Develops a structured, logical, and step-by-step plan to achieve a real-world goal. Use this for requests that involve business, logistics, learning, or problem-solving in the 'real world'.",
            "parameters": {
                "type": "object",
                "properties": {
                    "goal": {
                        "type": "string",
                        "description": "The real-world goal for which the strategic plan is needed."
                    }
                },
                "required": ["goal"]
            }
        }
    }
]

# --- Tool Implementations (Python Functions) ---

def web_search(query: str) -> str:
    """
    Simulates a web search. In a real-world scenario, this would call a search API.
    Due to sandbox limitations, we provide a placeholder and a hint for the LLM.
    """
    # Note: In a real deployment, you would integrate with a search API here.
    # For this sandbox, we simulate the result to allow the LLM to continue its reasoning.
    return json.dumps({
        "status": "success",
        "result": f"Search results for '{query}' are not available through this simulated tool. Please assume the current date is Dec 10, 2025. The capital of Saudi Arabia is Riyadh. The LLM should use its internal knowledge or state the need for external search."
    })

def generate_image(prompt: str) -> str:
    """
    Generates an image using DALL-E and returns the URL.
    """
    try:
        # Generate the image
        response = client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            n=1,
            size="1024x1024"
        )
        
        image_url = response.data[0].url
        
        # Return the URL and a marker for the main handler
        return json.dumps({"status": "success", "image_url": image_url, "prompt": prompt})
    except Exception as e:
        logger.error(f"Image generation error: {e}")
        return json.dumps({"status": "error", "message": f"Failed to generate image: {e}"})

def run_code(code: str) -> str:
    """
    Executes Python code safely and captures the output.
    """
    old_stdout = io.StringIO()
    redirect_stdout = contextlib.redirect_stdout(old_stdout)
    
    # Restrict built-ins and globals for safety
    safe_globals = {
        "__builtins__": {
            "print": print,
            "len": len,
            "range": range,
            "str": str,
            "int": int,
            "float": float,
            "list": list,
            "dict": dict,
            "tuple": tuple,
            "set": set,
            "sum": sum,
            "max": max,
            "min": min,
            "abs": abs,
            "round": round,
            "pow": pow,
            "sorted": sorted,
            "enumerate": enumerate,
            "zip": zip,
            "map": map,
            "filter": filter,
            "isinstance": isinstance,
            "type": type,
            "Exception": Exception,
        }
    }
    
    try:
        with redirect_stdout:
            exec(code, safe_globals)
        output = old_stdout.getvalue().strip()
        return json.dumps({"status": "success", "output": output if output else "Code executed successfully with no output."})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})

def creative_planner(topic: str) -> str:
    """
    Simulates a highly creative planning tool.
    """
    return json.dumps({
        "status": "success",
        "plan": f"Creative Plan for '{topic}': The model should now use its internal knowledge to generate a highly imaginative and detailed response about the topic, as if the tool provided a framework for a fantastical story or concept."
    })

def strategic_planner(goal: str) -> str:
    """
    Simulates a strategic planning tool.
    """
    return json.dumps({
        "status": "success",
        "plan": f"Strategic Plan for '{goal}': The model should now use its internal knowledge to generate a structured, step-by-step, and logical plan to achieve the goal, as if the tool provided a business or life strategy framework."
    })

AVAILABLE_TOOLS = {
    "web_search": web_search,
    "run_code": run_code,
    "generate_image": generate_image,
    "creative_planner": creative_planner,
    "strategic_planner": strategic_planner,
}

# --- Telegram Handlers ---

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Sends a welcome message when the command /start is issued."""
    if update.message.chat_id != ALLOWED_CHAT_ID:
        await update.message.reply_text("عذراً، هذا البوت مخصص لمالكه فقط.")
        return
    
    welcome_message = (
        "أهلاً بك يا مالكي! أنا وكيل الذكاء الاصطناعي الخارق الخاص بك.\n"
        "أنا مبرمج لاستخدام أدوات متقدمة (البحث في الويب وتنفيذ الكود) لحل المهام المعقدة.\n"
        "فقط أرسل لي سؤالك أو طلبك وسأقوم بمعالجته."
    )
    await update.message.reply_text(welcome_message)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Sends a help message when the command /help is issued."""
    if update.message.chat_id != ALLOWED_CHAT_ID:
        return
    
    help_message = (
        "**كيفية استخدام الوكيل الخارق:**\n"
        "1. **للأسئلة العامة:** أرسل سؤالك مباشرة (مثال: ما هي عاصمة مصر؟).\n"
        "2. **للحسابات:** اطلب مني إجراء عملية حسابية معقدة (مثال: احسب الجذر التربيعي لـ 123456).\n"
        "3. **للمعلومات الحديثة:** اطلب معلومات حديثة (مثال: ما هي آخر أخبار كأس العالم؟).\n"
        "سأقوم تلقائيًا بتحديد الأداة المناسبة (تنفيذ الكود أو البحث) للإجابة على طلبك."
    )
    await update.message.reply_markdown(help_message)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handles all incoming text messages and processes them using the LLM with tool calling."""
    chat_id = update.message.chat_id
    if chat_id != ALLOWED_CHAT_ID:
        logger.warning(f"Unauthorized access attempt from chat ID: {chat_id}")
        await update.message.reply_text("عذراً، هذا البوت مخصص لمالكه فقط.")
        return

    user_message = update.message.text
    await update.message.reply_text("جاري التفكير والعمل على طلبك...")
    
    messages = [
        {"role": "system", "content": (
            "أنت وكيل ذكاء اصطناعي خارق (Super-Agent) ومدمج في تليجرام. مهمتك هي مساعدة المستخدمين بأقصى قدر من الكفاءة والدقة، ولديك القدرة على التعامل مع أي طلب 'داخل العالم' أو 'خارجه'. "
            "أنت قادر على التفكير المنطقي واستخدام الأدوات المتاحة لك (web_search, run_code, generate_image, creative_planner, strategic_planner) لحل المهام المعقدة. "
            "استخدم الأداة المناسبة لكل طلب: 'strategic_planner' للمهام الواقعية، و 'creative_planner' للمهام الخيالية أو الإبداعية. "
            "يجب أن تكون جميع الردود مهذبة، احترافية، وموجهة نحو حل مشكلة المستخدم باللغة العربية الفصحى."
        )},
        {"role": "user", "content": user_message}
    ]
    
    # Tool Call Loop
    for _ in range(5): # Limit the number of tool calls to prevent infinite loops
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
            )
        except Exception as e:
            logger.error(f"OpenAI API Error: {e}")
            await update.message.reply_text(f"عذراً، حدث خطأ أثناء الاتصال بخدمة الذكاء الاصطناعي: {e}")
            return

        response_message = response.choices[0].message
        
        if response_message.tool_calls:
            messages.append(response_message) # Extend conversation with assistant's reply
            
            tool_outputs = []
            for tool_call in response_message.tool_calls:
                function_name = tool_call.function.name
                function_to_call = AVAILABLE_TOOLS.get(function_name)
                function_args = json.loads(tool_call.function.arguments)
                
                if function_to_call:
                    await update.message.reply_text(f"-> جاري تنفيذ الأداة: `{function_name}`...")
                    
                    # Execute the tool function
                    function_output = function_to_call(**function_args)
                    
                    tool_outputs.append({
                        "tool_call_id": tool_call.id,
                        "output": function_output,
                    })
                else:
                    logger.error(f"Unknown tool requested: {function_name}")
                    tool_outputs.append({
                        "tool_call_id": tool_call.id,
                        "output": json.dumps({"status": "error", "message": f"Tool not found: {function_name}"}),
                    })
            
            # Send tool outputs back to the model
            for output in tool_outputs:
                messages.append({
                    "role": "tool",
                    "name": response_message.tool_calls[0].function.name,
                    "content": output["output"],
                    "tool_call_id": output["tool_call_id"],
                })
            
            # Check if an image was generated and send it directly
            for output in tool_outputs:
                try:
                    output_data = json.loads(output["content"])
                    if "image_url" in output_data and output_data["status"] == "success":
                        image_url = output_data["image_url"]
                        prompt = output_data["prompt"]
                        await update.message.reply_photo(image_url, caption=f"تم إنشاء الصورة بناءً على طلبك: {prompt}")
                        # After sending the image, we can break the loop and return the final text response from the model
                        break
                except json.JSONDecodeError:
                    continue
            
            # Continue the loop to get the final response from the model
            continue
        
        # If no tool call, this is the final response
        final_response = response_message.content
        await update.message.reply_text(final_response)
        return

    # If the loop finishes without a final response (e.g., too many tool calls)
    await update.message.reply_text("عذراً، لم أتمكن من إنهاء معالجة طلبك بعد عدة محاولات لاستخدام الأدوات.")


def main() -> None:
    """Start the bot."""
    # Create the Application and pass it your bot's token.
    application = Application.builder().token(TOKEN).build()

    # on different commands - answer in Telegram
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))

    # on non command i.e message - handle the message
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Run the bot until the user presses Ctrl-C
    logger.info("Starting Telegram Bot...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
